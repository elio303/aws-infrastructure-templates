exports.handler = async (event, context) => {
  console.log(event, context);
};
